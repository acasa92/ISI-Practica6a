Messages= new Meteor.Collection("messages");
